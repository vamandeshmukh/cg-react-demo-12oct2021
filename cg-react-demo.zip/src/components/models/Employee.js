

class Employee {
    eid;
    firstName;
    salary;
}

export default Employee;