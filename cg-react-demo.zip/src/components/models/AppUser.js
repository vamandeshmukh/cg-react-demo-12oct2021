
class AppUser {
    userName;
    password;
    role;
}
export default AppUser;